﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constructors
{
    class UniversityStudent { public UniversityStudent() { } } // 1 задание

    class Kid { public Kid() { } } // 2 задание

    class Vehicle // 3 - 4 задание
    {
        public int releaseYear;
        public string model;
        public string bodyColor;

        public Vehicle(int releaseYear) // 3 задание
        {
            this.releaseYear = releaseYear;
        }

        public Vehicle(string model, string bodyColor) // 4 задание
        {
            this.model = model;
            this.bodyColor = bodyColor;
        }
    }

    class Item // 5 задание
    {
        protected string title;

        public Item(string title)
        {
            this.title = title;
        }

        public Item(Item other)
        {
            this.title = other.title;
        }
    }

    class Human // 6 задание
    {
        private int years;

        public Human()
        {
            years = 18;
        }

        public void Show()
        {
            Console.WriteLine(years);
        }
    }

    class Director // 7 задание
    {
        private int years;
        private string fullName;

        public Director(int years, string fullName)
        {
            this.years = years;
            this.fullName = fullName;
        }

        public Director(Director other)
        {
            this.years = other.years;
            this.fullName = other.fullName;
        }
    }

    class Program
    {
        static void Main()
        {
            Kid child1 = new Kid(); // 2 задание

            Vehicle car1 = new Vehicle(2026); // 3 задание

            Vehicle audi = new Vehicle("Audi A6", "gray"); // 4 задание
            Vehicle kia = new Vehicle("KIA Rio", "red");

            Item item1 = new Item("Товар 1"); // 5 задание
            Item item2 = new Item(item1);

            Human human1 = new Human(); // 6 задание
            human1.Show();

            Director dir1 = new Director(25, "Алина"); // 7 задание
            Director dir2 = new Director(dir1);
        }
    }
}

