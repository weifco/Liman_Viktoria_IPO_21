﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace encapcsulation
{
    using System;

    class StudentInfo // 1 задание
    {
        public string fullName;
    }

    class Auto // 2 задание
    {
        public int productionYear;
    }

    class Dot // 3 задание
    {
        public int coordinateX;
    }

    class Human // 4 задание
    {
        public int years;

        public void ShowAge()
        {
            Console.WriteLine($"Возраст: {years}");
        }
    }

    class Desk // 5 задание
    {
        public int height, width;

        public void ShowSize()
        {
            Console.WriteLine($"Высота: {height}, Ширина: {width}");
        }
    }

    class Supervisor // 6 задание
    {
        public int years;
        public string fullName;

        public void ShowYears()
        {
            Console.WriteLine($"Возраст: {years}");
        }

        public void ShowFullName()
        {
            Console.WriteLine($"Имя: {fullName}");
        }
    }

    class Point3DNew // 7 задание
    {
        public int x, y, z;

        public void Display()
        {
            Console.WriteLine($"Координаты: X={x}, Y={y}, Z={z}");
        }
    }

    class Store // 8 задание
    {
        public string currentName, changedName;

        public void ShowName()
        {
            Console.WriteLine($"Название магазина: {currentName}");
        }

        public void ChangeName()
        {
            currentName = changedName;
            Console.WriteLine($"Новое название магазина: {currentName}");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Human person1 = new Human(); // 4 задание
            person1.years = 18;
            person1.ShowAge();

            Desk desk1 = new Desk(); // 5 задание
            desk1.height = 10;
            desk1.width = 20;
            desk1.ShowSize();

            Supervisor manager1 = new Supervisor(); // 6 задание
            manager1.years = 30;
            manager1.fullName = "Анна";
            manager1.ShowYears();
            manager1.ShowFullName();

            Point3DNew point1 = new Point3DNew(); // 7 задание
            point1.x = 5;
            point1.y = 6;
            point1.z = 7;
            point1.Display();

            Store store1 = new Store(); // 8 задание
            store1.currentName = "Ромашка";
            store1.changedName = "Лаванда";
            store1.ShowName();
            store1.ChangeName();
        }
    }
}
