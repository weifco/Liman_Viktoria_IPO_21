﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace propertisClass
{
    class Pupil // 1 задание
    {
        public string FirstName { get; set; }
    }

    class Baby // 2 задание
    {
        public int YearsOld { get; set; }

        public Baby() { }
    }

    class Vehicle // 3 - 4 задание
    {
        private int manufactureYear; // 3 задание

        public int ManufactureYear
        {
            get { return manufactureYear; }
            set
            {
                if (value > 0)
                    manufactureYear = value;
            }
        }

        public string ModelName { get; set; } // 4 задание
        public string PaintColor { get; set; }

        public Vehicle() { }
    }

    class Item // 5 задание
    {
        protected string itemName;

        public string ItemName
        {
            get { return itemName; }
            private set { }
        }

        public Item()
        {
            itemName = "Кирилл";
        }
    }

    class Program
    {
        static void Main()
        {
            Pupil pupil = new Pupil(); // 1 задание
            pupil.FirstName = "Екатерина";

            Baby baby = new Baby { YearsOld = 8 }; // 2 задание

            Vehicle vehicle1 = new Vehicle(); // 3 задание
            vehicle1.ManufactureYear = 2022;

            Vehicle toyota = new Vehicle // 4 задание
            {
                ModelName = "Toyota Corolla",
                PaintColor = "silver"
            };

            Item item = new Item(); // 5 задание
            Console.WriteLine(item.ItemName);
        }
    }
}
