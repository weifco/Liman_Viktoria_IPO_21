﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Osn.Al._13._01
{


    class Student  //задание1
    {
        public string name = "";

        public void Print()
        {
            Console.WriteLine($"Имя:{name}");

        }
    }


    class Car    //задание2
    {
        public int year = 11;
    }

    
    class Point //задание3
    {
        public int x;
    }



    class Person     //задание4
    {
        public int age;
        public void Print()
        {
            Console.WriteLine($"Возраст:{age}");
        }

    }


 
    class Table    //задание5
    {
        public int rows;
        public int cols;

        public void Display()
        {
            Console.WriteLine($"Строчки:{rows}, Столбики:{cols}");
        }
    }

    

     class Manager      //задание6
    {
        public int age;
        public string name;

        public void GetAge()
        { 
            Console.WriteLine($"Возраст: {age}");
        }

        public void GetName()
        { 
            Console.WriteLine($"Имя: {name}"); 
        }
     }


 
        class Point3D        //задание7
    {
            public int x;
            public int y;
            public int z;

            public void Show()
            {
                Console.WriteLine($"Значение x: {x}, y: {y}, z: {z} ");
            }

        }



   
        class Shop      //задание8
    {
            public string name;
            public string newname;

            public void GetName()
            {
                Console.WriteLine($"Название магазина: {name}");
            }


            public void SetName()
            {
                Console.WriteLine($"Новое название магазина: {newname}");
            }
        }


    internal class Program//задание1
    {
        static void Main(string[] args)
        {
            //задание1
            {
                Student p1 = new Student();
                p1.name = "Vika";
                p1.Print();
            }

            //задание4
            {
                Person person1 = new Person();
                person1.age = 17;
                person1.Print();
            }


            //задание5
            {
                Table table1 = new Table();
                table1.rows = 12;
                table1.cols = 10;
                table1.Display();
            }

            //задание6
            {
                Manager manager1 = new Manager();
                manager1.age = 23;
                manager1.name = "Марина";
                manager1.GetName();
                manager1.GetAge();

            }


            //задание7
            {
                Point3D point3D = new Point3D();
                point3D.x = 6;
                point3D.y = 4;
                point3D.z = 9;
                point3D.Show();
            }

            //задание8
            {
                Shop shop = new Shop();
                shop.name = "Белуга";
                shop.newname = "Рыба Мечты";
                shop.GetName();
                shop.SetName();
            }


        }
    }  
}